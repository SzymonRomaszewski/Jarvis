## What and why

<!-- A sentence or two: what changes, and the problem it solves. -->

## Checklist

- [ ] Tests added or updated, and `python -m unittest discover -s tests` passes
- [ ] `python scripts/check_names.py jarvis.py` is clean
- [ ] New settings or flags are documented (`docs/configuration.md` / README)
- [ ] `python scripts/gen_tools_doc.py` run if a tool changed
- [ ] Tools that act on the Mac or read outside content considered for confirmation and untrusted-content handling
- [ ] No keys, tokens or personal data in the diff
