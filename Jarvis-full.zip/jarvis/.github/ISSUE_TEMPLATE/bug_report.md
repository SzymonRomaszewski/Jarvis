---
name: Bug report
about: Something isn't working
labels: bug
---

**What happened?**

**What did you expect?**

**How to reproduce**

**Environment**
- macOS version and chip (for example macOS 15, M3):
- Python version:
- Brain (groq / gemini / claude / ollama):
- Output of `python jarvis.py --check`:

**Terminal output around the problem** (remove any keys!)

```
```
