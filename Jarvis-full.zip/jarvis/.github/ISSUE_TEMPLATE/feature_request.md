---
name: Feature request
about: An idea for Jarvis
labels: enhancement
---

**What would you like Jarvis to do?** What would you say to it?

**Why is it useful?**

**Anything it needs?** (a free API, a macOS permission, a paid key...)

**Safety:** could this act on the Mac or read content from outside? If so, how should it be confirmed or restricted?
